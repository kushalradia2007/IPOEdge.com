import os
from dotenv import load_dotenv

load_dotenv()

import csv
from flask import Flask, jsonify, render_template, request
from flask_sqlalchemy import SQLAlchemy
from google import genai

# genai client will automatically pick up GEMINI_API_KEY from environment
# We'll initialize it in the route to handle missing keys gracefully

# --- HELPER FUNCTIONS ---
def to_float_or_none(value):
    if value is None or (isinstance(value, str) and value.strip() == ''):
        return None
    try:
        cleaned_value = str(value).replace(',', '').replace('Rs.', '').replace('to', '').strip()
        cleaned_value = cleaned_value.split()[0] 
        return float(cleaned_value)
    except (ValueError, TypeError, IndexError):
        return None

basedir = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__)

if os.environ.get('DATABASE_URL'):
    uri = os.environ.get('DATABASE_URL')
    if isinstance(uri, str) and uri.startswith('postgres://'):
        uri = uri.replace('postgres://', 'postgresql://', 1)
    app.config['SQLALCHEMY_DATABASE_URI'] = uri
else:
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'ipos.db')

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


# --- DATABASE MODEL ---
class IPO(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.String(20), nullable=False) 
    ipo_name = db.Column(db.String(255), nullable=False)
    issue_size_crores = db.Column(db.Float, nullable=True) 
    qib = db.Column(db.Float, nullable=True) 
    hni = db.Column(db.Float, nullable=True) 
    rii = db.Column(db.Float, nullable=True) 
    total_subscription = db.Column(db.Float, nullable=True) 
    offer_price = db.Column(db.Float, nullable=True)
    list_price = db.Column(db.Float, nullable=True)
    listing_gain = db.Column(db.Float, nullable=True)
    cmp_bse = db.Column(db.Float, nullable=True) 
    cmp_nse = db.Column(db.Float, nullable=True) 
    current_gains = db.Column(db.Float, nullable=True) 

with app.app_context():
    db.create_all()


# --- ROUTES ---
@app.route('/ask-gemini', methods=['POST'])
def ask_gemini():
    try:
        data = request.get_json()
        user_prompt = data.get('prompt')
        
        if not user_prompt:
            return jsonify({'error': 'No prompt provided'}), 400

        system_context = "You are a highly knowledgeable financial AI assistant for a platform called 'IPO Edge'. Be concise, professional, and helpful. Format your responses plainly without heavy markdown. Answer the following query: "
        
        client = genai.Client()
        response = client.models.generate_content(
            model='gemini-2.0-flash',
            contents=system_context + user_prompt
        )
        return jsonify({'response': response.text})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/load-data')
def load_csv_data():
    file_path = os.path.join(basedir, 'ipo_data.csv')
    IPO.query.delete()
    db.session.commit()

    records_added = 0
    try:
        with open(file_path, mode='r', encoding='cp1252') as csvfile:
            reader = csv.DictReader(csvfile)

            for row in reader:
                clean_row = {str(k).strip(): v for k, v in row.items() if k}
                date_val = clean_row.get('Date')
                name_val = clean_row.get('IPO_Name')

                if not name_val or not date_val:
                    continue

                data = {
                    'date': date_val,
                    'ipo_name': name_val,
                    'issue_size_crores': to_float_or_none(clean_row.get('Issue_Size(crores)')),
                    'qib': to_float_or_none(clean_row.get('QIB')),
                    'hni': to_float_or_none(clean_row.get('HNI')),
                    'rii': to_float_or_none(clean_row.get('RII')),
                    'total_subscription': to_float_or_none(clean_row.get('Total')),
                    'offer_price': to_float_or_none(clean_row.get('Offer Price')),
                    'list_price': to_float_or_none(clean_row.get('List Price')),
                    'listing_gain': to_float_or_none(clean_row.get('Listing Gain')),
                    'cmp_bse': to_float_or_none(clean_row.get('CMP(BSE)')),
                    'cmp_nse': to_float_or_none(clean_row.get('CMP(NSE)')),
                    'current_gains': to_float_or_none(clean_row.get('Current Gains')),
                }

                ipo = IPO(**data)
                db.session.add(ipo)
                records_added += 1

        db.session.commit()
        return jsonify({
            "message": f"Successfully loaded and added {records_added} IPO records.",
            "info": "Please refresh the page."
        })
    except Exception as e:
        return jsonify({"error": "Failed to read CSV", "message": str(e)})


@app.route('/')
def home():
    return render_template('website.html')

@app.route('/companies')
def companies():
    ipo_records = IPO.query.all() 
    return render_template('Companies.html', ipo_records=ipo_records)

@app.route('/calendar')
def calendar():
    return render_template('Calendar.html')

@app.route('/dive_deeper_with_ai')
def dive_deeper_with_ai():
    return render_template('Dive_Deeper_with_AI.html')

@app.route('/learning_videos')
def learning_videos():
    return render_template('Learning_Videos.html')

if __name__ == '__main__':
    app.run(debug=True)